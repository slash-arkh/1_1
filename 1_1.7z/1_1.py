
a = input()
a = str(a)
print(len(a))

b = int(input())
c = int(input())
sum = b + c
m = b - c
print(str(sum) , str(m))

a = int(input())
b = int(input())
c = int(input())
d = [a, b, c]
h = sum(d) / len(d)
print(str(h))

a = 'Вторник'
b = 'Понедельник'
print(b + ', ' + a)

a = int(input())
b = int(input())
c = int(input())
f = (((a * b) + (a * c)) ** 3) / 2
print(f)